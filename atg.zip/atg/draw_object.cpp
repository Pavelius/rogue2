#include "adat.h"
#include "bsdata.h"
#include "draw.h"
#include "draw_object.h"
#include "pushvalue.h"
#include "slice.h"
#include "timer.h"

point camera_maximum;
drawable* last_object;

static adat<drawable*, 256> objects;
static rect last_screen, last_area;
static unsigned long timestamp, timestamp_last;

BSDATAC(drawobject, 128)

bool drawable::onscreen() const {
	return position.in(last_area);
}

int object_def_sort(const void* object) {
	return ((drawable*)object)->priority;
}

static void update_timestamp() {
	auto c = getcputime();
	if(!timestamp_last || (c - timestamp_last) > 300)
		timestamp_last = c;
	timestamp += c - timestamp_last;
	timestamp_last = c;
}

static int compare(const void* v1, const void* v2) {
	auto p1 = *((drawable**)v1);
	auto p2 = *((drawable**)v2);
	auto r1 = p1->priority / 5;
	auto r2 = p2->priority / 5;
	if(r1 != r2)
		return r1 - r2;
	if(p1->position.y != p2->position.y)
		return p1->position.y - p2->position.y;
	if(p1->priority != p2->priority)
		return p1->priority - p2->priority;
	if(p1->position.x != p2->position.x)
		return p1->position.x - p2->position.x;
	return p1 - p2;
}

void sort_objects() {
	qsort(objects.data, objects.count, sizeof(objects.data[0]), compare);
}

void clear_drawobjects() {
	bsdata<drawobject>::source.clear();
}

void clear_objects() {
	objects.clear();
}

void set_srceen_area(int offset) {
	last_screen = {caret.x, caret.y, caret.x + width, caret.y + height};
	last_area = last_screen; last_area.move(camera.x, camera.y);
	last_area.offset(offset, offset);
	camera_correct();
}

void paint_objects() {
	pushrect push;
	pushvalue push_last(last_object);
	for(auto p : objects) {
		last_object = p;
		caret = p->position - camera;
		bsdata<drawrender>::elements[p->render].proc();
	}
}

void for_each_object(fnevent proc) {
	pushrect push;
	pushvalue push_last(last_object);
	for(auto p : objects) {
		last_object = p;
		caret = p->position - camera;
		proc();
	}
}

static int screen_width() {
	auto r = last_screen.width();
	if(!r)
		r = getwidth();
	return r;
}

static int screen_height() {
	auto r = last_screen.height();
	if(!r)
		r = getheight();
	return r;
}

void camera_correct() {
	if(camera.x > camera_maximum.x - screen_width())
		camera.x = camera_maximum.x - screen_width();
	if(camera.y > camera_maximum.y - screen_height())
		camera.y = camera_maximum.y - screen_height();
	if(camera.x < 0)
		camera.x = 0;
	if(camera.y < 0)
		camera.y = 0;
}

void camera_set_screen(int x, int y) {
	last_screen.set(0, 0, x, y);
	last_area = last_screen;
}

void camera_set(point v) {
	v.x -= screen_width() / 2;
	v.y -= screen_height() / 2;
	camera = v;
	camera_correct();
}

bool camera_visible(point goal, int border) {
	rect rc = {camera.x, camera.y, camera.x + last_screen.width(), camera.y + last_screen.height()};
	rc.offset(-border);
	return goal.in(rc);
}

void add_object(rendern render, point v, short unsigned frame, unsigned char priority) {
	auto p = bsdata<drawobject>::add();
	p->render = render;
	p->position = v;
	p->frame = frame;
	p->priority = priority;
	objects.add(p);
}

void add_object(drawable* p) {
	objects.add(p);
}