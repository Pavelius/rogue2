///////////////////////////////////////////////////////////////////////////
// 
//  Copyright 2026 by Pavel Chistyakov
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http ://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.

#include "bsdata.h"
#include "creature.h"
#include "io_stream.h"
#include "item.h"
#include "pushvalue.h"
#include "sprite_util.h"
#include "stringlocale.h"

using namespace util;

char const* util::image_source = "D:/games/adom/gfx/adom";
char const* source_folder = 0;

static sprite* create_sprite(int count, int cicles = 0, int additional = 0, int size = 1024 * 1024 * 4) {
	auto p = new unsigned char[size];
	sprite_create((sprite*)p, count, cicles, additional);
	return (sprite*)p;
}

static void close_sprite(sprite* p, const char* id, const char* folder = "art") {
	char temp[260];
	sprite_write(szurl(temp, 0, folder, id, "pma"), p);
	delete[](unsigned char*)p;
}

static void add(sprite* p, const char* id, point position) {
	util::add(p, source_folder, id, -1, position, util::add_image);
}

static void convert_items() {
	static const char* avatars[] = {
		"items37", "items37", "items37",
		"item6", "item60", "item3", "item7", "item42", "item24", "item189",
		"item0", "item2", "item4", "item36", "item190",
		"item50", "item76", "item67", "item77",
		"item8", "item29", "item43", "item10", "item11", "item12", "item13",
		"item488", "item482", "item567",
		"item476",
	};
	assert_enum(avatars, LastItem);
	pushvalue push(source_folder, "items");
	auto p = create_sprite(LastItem + 1);
	for(auto s : avatars)
		add(p, s, {-1000, -1000});
	close_sprite(p, "items");
}

static point get_offset(monstern v) {
	switch(v) {
	case GiantFrog: return point(36, -16);
	case DireBoar: return point(36, -24);
	default: return point(-1000, -24);
	}
}

static void convert_monsters() {
	pushvalue push(source_folder, "NPC");
	auto p = create_sprite(LastMonster - FirstMonster + 1);
	for(auto i = FirstMonster; i <= LastMonster; i = (monstern)(i + 1))
		add(p, get_avatar(i), get_offset(i));
	close_sprite(p, "monsters");
}

static void convert_fonts() {
	font_write_ascii("art/font.pma", "Segoe UI", 14, sprite::ALC1);
	font_write_ascii("art/h1.pma", "Segoe UI", 18, sprite::ALC1);
	font_write_ascii("art/h2.pma", "Segoe UI", 20, sprite::ALC1);
	font_write_ascii("art/h3.pma", "Segoe UI", 24, sprite::ALC1);
}

static void convert_statuses() {
	static const char* avatars[] = {
		"afraid", "berserk", "bleed", "bless", "blind", "bloated", "burdened",
		"confused", "deaf", "drunk", "hungry!", "hungry",
		"stunned",
	};
	pushvalue push(source_folder, "nterface/status");
	auto p = create_sprite(lenghtof(avatars));
	for(auto pa : avatars)
		add(p, pa, point(-1000, -1000));
	close_sprite(p, "status");
}

void main_util() {
	convert_statuses();
	// convert_fonts();
	// convert_monsters();
	// convert_items();
}