///////////////////////////////////////////////////////////////////////////
// 
//  Copyright 2026 by Pavel Chistyakov
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http ://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.

#pragma once

struct sprite;

enum resid : unsigned char {
	FontT, Font1, Font2, Font3,
	ResPCBody, ResPCArms, ResPCAccessories,
	ResFow, ResLos,
	ResFloor, ResBorders, ResDecals, ResFeatures, ResItems, ResMonsters,
	ResStatus, ResConditions, ResSplash,
	ResWalls, ResShadows,
};

sprite* gres(resid id);